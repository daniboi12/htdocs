<link rel="stylesheet" type="text/css" href="css/all.css" />
<link rel="stylesheet" type="text/css" href="css/nav.css" />
<link rel="stylesheet" type="text/css" href="css/footer.css" />
<script src="https://kit.fontawesome.com/1e30e30b42.js" crossorigin="anonymous"></script>
