<header id="header">
      <img class="logo" src="images/logo.svg" alt="logo" />

      <table>
        <tr>
          <nav>
            <ul id="navLinks">
              <li><a href="index.php">HOME</a></li>
              <li><a href="stories.php">STORIES</a></li>
              <li><a href="calendar.php">CALENDAR</a></li>
              <li><a href="about.php">ABOUT</a></li>
            </ul>
          </nav>
        </tr>
      </table>

      <button class="navButton">CONTACT</button>
</header>